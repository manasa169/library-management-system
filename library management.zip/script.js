const loggedIn = JSON.parse(localStorage.getItem('loggedIn'));
if(!loggedIn) {
  window.location.href = 'login.html';
} else {
  // Display user info in header
  const header = document.querySelector('header h1');
  header.textContent += ` - Logged in as: ${loggedIn.type.toUpperCase()} (${loggedIn.username})`;
}

// Logout button
document.getElementById('logoutBtn').addEventListener('click', function(){
  localStorage.removeItem('loggedIn');
  window.location.href = 'login.html';
});